
package com.vmware.vim25;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ArrayOfExtensionTaskTypeInfo complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ArrayOfExtensionTaskTypeInfo">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="ExtensionTaskTypeInfo" type="{urn:vim25}ExtensionTaskTypeInfo" maxOccurs="unbounded" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ArrayOfExtensionTaskTypeInfo", propOrder = {
    "extensionTaskTypeInfo"
})
public class ArrayOfExtensionTaskTypeInfo {

    @XmlElement(name = "ExtensionTaskTypeInfo")
    protected List<ExtensionTaskTypeInfo> extensionTaskTypeInfo;

    /**
     * Gets the value of the extensionTaskTypeInfo property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the extensionTaskTypeInfo property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getExtensionTaskTypeInfo().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ExtensionTaskTypeInfo }
     * 
     * 
     */
    public List<ExtensionTaskTypeInfo> getExtensionTaskTypeInfo() {
        if (extensionTaskTypeInfo == null) {
            extensionTaskTypeInfo = new ArrayList<ExtensionTaskTypeInfo>();
        }
        return this.extensionTaskTypeInfo;
    }

}
