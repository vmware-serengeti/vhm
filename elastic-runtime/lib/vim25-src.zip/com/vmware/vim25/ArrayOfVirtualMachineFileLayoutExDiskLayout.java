
package com.vmware.vim25;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ArrayOfVirtualMachineFileLayoutExDiskLayout complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ArrayOfVirtualMachineFileLayoutExDiskLayout">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="VirtualMachineFileLayoutExDiskLayout" type="{urn:vim25}VirtualMachineFileLayoutExDiskLayout" maxOccurs="unbounded" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ArrayOfVirtualMachineFileLayoutExDiskLayout", propOrder = {
    "virtualMachineFileLayoutExDiskLayout"
})
public class ArrayOfVirtualMachineFileLayoutExDiskLayout {

    @XmlElement(name = "VirtualMachineFileLayoutExDiskLayout")
    protected List<VirtualMachineFileLayoutExDiskLayout> virtualMachineFileLayoutExDiskLayout;

    /**
     * Gets the value of the virtualMachineFileLayoutExDiskLayout property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the virtualMachineFileLayoutExDiskLayout property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getVirtualMachineFileLayoutExDiskLayout().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link VirtualMachineFileLayoutExDiskLayout }
     * 
     * 
     */
    public List<VirtualMachineFileLayoutExDiskLayout> getVirtualMachineFileLayoutExDiskLayout() {
        if (virtualMachineFileLayoutExDiskLayout == null) {
            virtualMachineFileLayoutExDiskLayout = new ArrayList<VirtualMachineFileLayoutExDiskLayout>();
        }
        return this.virtualMachineFileLayoutExDiskLayout;
    }

}
